(() => {
  const PANEL_ID = "velocity-extension-panel";
  if (window.__velocityExtension) {
    window.__velocityExtension.toggle();
    return;
  }

  const state = { speed: 1, hidden: false, minimized: false, drag: null, timer: null };
  const previousSpeed = Number(window.__velocitySpeed) || 1;
  state.speed = Math.max(0.25, Math.min(16, previousSpeed));

  const style = document.createElement("style");
  style.textContent = `
    #${PANEL_ID},#${PANEL_ID} *{box-sizing:border-box}
    #${PANEL_ID}{color:#f5f5ff;background:rgba(22,23,35,.97);border:1px solid #ffffff24;border-radius:16px;box-shadow:0 16px 55px #0009;backdrop-filter:blur(18px);font:13px/1.45 system-ui,-apple-system,Segoe UI,sans-serif;overflow:hidden;user-select:none}
    #${PANEL_ID} button{font:inherit;color:inherit;background:#ffffff0b;border:1px solid #ffffff1b;border-radius:9px;padding:7px 9px;cursor:pointer;transition:background .12s,border-color .12s}
    #${PANEL_ID} button:hover{background:#ffffff20;border-color:#a99aff}
    #${PANEL_ID} button:focus-visible,#${PANEL_ID} input:focus-visible{outline:2px solid #a99aff;outline-offset:2px}
    #${PANEL_ID} .vs-preset{padding:7px 0;text-align:center}
    #${PANEL_ID} .vs-preset.active{background:#8d7bff30;border-color:#a99aff;color:#d7ceff}
    #${PANEL_ID} .vs-section{border-top:1px solid #ffffff12;padding:12px 14px}
    #${PANEL_ID} .vs-muted{font-size:11px;color:#a8abc0}
    #${PANEL_ID} input[type=range]{width:100%;accent-color:#a99aff;cursor:pointer}
    #${PANEL_ID} .vs-row{display:flex;align-items:center;gap:7px}
    #${PANEL_ID} .vs-head{cursor:move;touch-action:none}
  `;

  const make = (tag, text, parent, css) => {
    const node = document.createElement(tag);
    if (text !== null && text !== undefined) node.textContent = text;
    if (css) node.style.cssText = css;
    if (parent) parent.appendChild(node);
    return node;
  };

  function buildPanel() {
    const existing = document.getElementById(PANEL_ID);
    if (existing) existing.remove();
    if (!style.isConnected) document.head.appendChild(style);

    const panel = make("div", null, document.body,
      `position:fixed;z-index:2147483647;top:90px;left:24px;width:300px;max-width:calc(100vw - 16px);`);
    panel.id = PANEL_ID;

    const head = make("div", null, panel,
      "display:flex;align-items:center;gap:10px;padding:13px 14px;background:linear-gradient(110deg,#9b88ff24,transparent);border-bottom:1px solid #ffffff12;");
    head.className = "vs-row vs-head";
    make("div", "ϟ", head, "width:32px;height:32px;display:grid;place-items:center;border-radius:10px;background:#a99aff;color:#211936;font-size:21px;font-weight:900;");
    const title = make("div", null, head, "flex:1;min-width:0;");
    make("div", "Velocity", title, "font-size:15px;font-weight:800;letter-spacing:.2px;");
    make("div", "VIDEO SPEED CONTROL · EXTENSION", title, "font-size:9px;color:#a8abc0;letter-spacing:.35px;");
    const mini = make("button", "−", head, "width:30px;padding:4px;");
    mini.title = "Minimize";
    const close = make("button", "×", head, "width:30px;padding:4px;");
    close.title = "Hide panel";

    const body = make("div", null, panel);
    const main = make("div", null, body, "padding:15px 14px;");
    const line = make("div", null, main, "display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;");
    const value = make("div", null, line, "font-size:32px;font-weight:800;letter-spacing:-1px;font-variant-numeric:tabular-nums;");
    const badge = make("div", "CUSTOM", line, "font-size:10px;padding:4px 7px;border-radius:7px;background:#8d7bff25;color:#d2caff;");
    const slider = make("input", null, main, "margin:5px 0;");
    slider.type = "range"; slider.min = ".25"; slider.max = "16"; slider.step = ".05";
    slider.setAttribute("aria-label", "Playback speed");
    const limits = make("div", null, main, "display:flex;justify-content:space-between;color:#a8abc0;font-size:10px;");
    limits.append("0.25×"); limits.appendChild(document.createTextNode("16×"));
    const fine = make("div", null, main, "display:flex;gap:7px;margin-top:12px;");
    const down = make("button", "− 0.1×", fine, "flex:1;");
    const reset = make("button", "Reset 1×", fine, "flex:1;font-weight:700;");
    const up = make("button", "+ 0.1×", fine, "flex:1;");

    const presetBox = make("div", null, body); presetBox.className = "vs-section";
    make("div", "QUICK SPEEDS", presetBox, "font-size:10px;color:#a8abc0;letter-spacing:.7px;");
    const grid = make("div", null, presetBox, "display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;margin-top:9px;");
    const presetValues = [.25,.5,.75,1,1.25,1.5,2,3,4,5,8,10,16];
    const presetButtons = [];
    const statusBox = make("div", null, body); statusBox.className = "vs-section";
    const status = make("div", null, statusBox, "font-size:11px;color:#c6c8d7;");
    const help = make("div", null, body); help.className = "vs-section vs-muted";
    help.textContent = "[ / ]  slower / faster   ·   \\  reset\n+ / −  fine adjust   ·   Alt + V  hide/show";
    help.style.whiteSpace = "pre-line";

    const fmt = n => Number(n).toFixed(2).replace(/0+$/, "").replace(/\.$/, "") + "×";
    function videos() { return Array.from(document.querySelectorAll("video")).filter(v => v.isConnected); }
    function apply() {
      const list = videos(); let ok = 0;
      for (const video of list) {
        try {
          if (Math.abs(video.playbackRate - state.speed) > .001) video.playbackRate = state.speed;
          if (Math.abs(video.playbackRate - state.speed) < .01) ok++;
        } catch (_) {}
      }
      status.textContent = list.length
        ? (ok === list.length ? `● Speed applied · ${list.length} video${list.length === 1 ? "" : "s"}` : "● Applying speed…")
        : "● Waiting for HTML5 video";
      status.style.color = list.length ? "#86e5b6" : "#e7c37b";
    }
    function setSpeed(n) {
      state.speed = Math.round(Math.max(.25, Math.min(16, Number(n))) * 100) / 100;
      window.__velocitySpeed = state.speed;
      value.textContent = fmt(state.speed); slider.value = state.speed;
      badge.textContent = state.speed === 1 ? "NORMAL" : "CUSTOM";
      presetButtons.forEach(([p, b]) => b.classList.toggle("active", Math.abs(p - state.speed) < .001));
      chrome.storage.local.set({ velocitySpeed: state.speed });
      apply();
    }
    presetValues.forEach(n => {
      const b = make("button", fmt(n), grid); b.className = "vs-preset";
      presetButtons.push([n, b]); b.addEventListener("click", () => setSpeed(n));
    });
    slider.addEventListener("input", () => setSpeed(slider.value));
    down.addEventListener("click", () => setSpeed(state.speed - .1));
    up.addEventListener("click", () => setSpeed(state.speed + .1));
    reset.addEventListener("click", () => setSpeed(1));

    function toggleMinimize() {
      state.minimized = !state.minimized;
      body.style.display = state.minimized ? "none" : "block";
      mini.textContent = state.minimized ? "+" : "−";
      mini.title = state.minimized ? "Expand" : "Minimize";
      panel.style.width = state.minimized ? "220px" : "300px";
    }
    mini.addEventListener("click", e => { e.stopPropagation(); toggleMinimize(); });
    close.addEventListener("click", e => { e.stopPropagation(); hide(); });
    panel.addEventListener("pointerdown", e => e.stopPropagation());

    head.addEventListener("pointerdown", e => {
      if (e.target.closest("button")) return;
      const r = panel.getBoundingClientRect();
      state.drag = { x: e.clientX, y: e.clientY, left: r.left, top: r.top };
      try { head.setPointerCapture(e.pointerId); } catch (_) {}
    });
    head.addEventListener("pointermove", e => {
      if (!state.drag) return;
      panel.style.left = Math.max(0, Math.min(innerWidth - panel.offsetWidth, state.drag.left + e.clientX - state.drag.x)) + "px";
      panel.style.top = Math.max(0, Math.min(innerHeight - 40, state.drag.top + e.clientY - state.drag.y)) + "px";
      panel.style.right = "auto";
    });
    const endDrag = () => { state.drag = null; };
    head.addEventListener("pointerup", endDrag);
    head.addEventListener("pointercancel", endDrag);

    state.setSpeed = setSpeed;
    state.apply = apply;
    setSpeed(state.speed);
    return panel;
  }

  function hide() {
    const panel = document.getElementById(PANEL_ID);
    if (panel) panel.style.display = "none";
    state.hidden = true;
  }
  function toggle() {
    const panel = document.getElementById(PANEL_ID);
    if (!panel) { state.hidden = false; buildPanel(); return; }
    state.hidden = panel.style.display !== "none";
    panel.style.display = state.hidden ? "none" : "block";
    if (!state.hidden) state.apply();
  }
  function onOutside(e) {
    const panel = document.getElementById(PANEL_ID);
    if (panel && !state.hidden && !panel.contains(e.target)) hide();
  }
  function onKey(e) {
    if (e.altKey && e.key.toLowerCase() === "v") { e.preventDefault(); toggle(); return; }
    if (state.hidden || e.ctrlKey || e.metaKey || e.altKey) return;
    const target = e.target;
    if (target && (target.isContentEditable || /INPUT|TEXTAREA|SELECT/.test(target.tagName))) return;
    let next = null;
    if (e.key === "]" || e.key === "ArrowUp") next = state.speed + .1;
    else if (e.key === "[" || e.key === "ArrowDown") next = state.speed - .1;
    else if (e.key === "\\") next = 1;
    else if (e.key === "+" || e.key === "=") next = state.speed + .05;
    else if (e.key === "-" || e.key === "_") next = state.speed - .05;
    if (next !== null) { e.preventDefault(); state.setSpeed(next); }
  }
  function cleanup() {
    clearInterval(state.timer);
    document.removeEventListener("pointerdown", onOutside, true);
    document.removeEventListener("keydown", onKey, true);
    const panel = document.getElementById(PANEL_ID); if (panel) panel.remove();
    style.remove(); delete window.__velocityExtension;
  }

  chrome.storage.local.get({ velocitySpeed: state.speed }, result => {
    state.speed = Math.max(.25, Math.min(16, Number(result.velocitySpeed) || state.speed));
    buildPanel();
  });
  document.addEventListener("pointerdown", onOutside, true);
  document.addEventListener("keydown", onKey, true);
  state.timer = setInterval(() => { if (state.apply) state.apply(); }, 1500);
  window.__velocityExtension = { toggle, hide, cleanup };
})();
