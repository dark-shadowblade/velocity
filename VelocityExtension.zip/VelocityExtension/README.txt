VELOCITY VIDEO SPEED CONTROLLER — CHROME EXTENSION

Install in Chrome (unpacked extension):
1. Extract VelocityExtension.zip to a normal folder.
2. Open chrome://extensions
3. Enable Developer mode.
4. Click Load unpacked.
5. Select the extracted VelocityExtension folder (the folder containing manifest.json).
6. Open a normal webpage with a video and click the Velocity extension icon.

Use:
- Click the extension icon to show/hide the floating panel.
- Click outside the panel to hide it; click the extension icon or press Alt+V to reopen.
- Drag the top bar to move the panel.
- Use the slider, quick presets, +/- buttons, or Reset 1x.
- [ and ] change speed by 0.1x; backslash resets to 1x.
- + and - change speed by 0.05x.
- The selected speed is saved in extension storage and reused on pages where the controller is opened.

Notes:
- Works on pages where Chrome permits extension injection; it cannot run on chrome:// pages or the Chrome Web Store.
- Some embedded/cross-origin players may not expose a controllable HTML5 video element.
